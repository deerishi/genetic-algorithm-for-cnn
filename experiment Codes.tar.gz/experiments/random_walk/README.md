dataset: 25% of MNIST
chromo_size: 500
iterations: 200
point_mutation: 10%
