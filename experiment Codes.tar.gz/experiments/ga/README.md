dataset: 25% of MNIST
chromo_size: 500
max_gen: 20
pop_size: 10
t_size: 2
point_mutation: 10%
